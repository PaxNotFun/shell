// index.js
const fs = require('node:fs');
const path = require('node:path');
const { Client, GatewayIntentBits, Collection, Partials, ActivityType } = require('discord.js'); // Añadido ActivityType si no estaba
const { token } = require('./config.json'); // Asegúrate que config.json esté en la raíz

// Crear cliente con intents necesarios
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent, // Solo si realmente lo necesitas
        GatewayIntentBits.GuildVoiceStates, // Esencial para voz
        GatewayIntentBits.GuildMembers,    // Útil para fetchOwner y otros checks
    ],
     partials: [Partials.Channel] // Puede ser útil
});

// Colección para comandos
client.commands = new Collection();
// Mapa para gestionar estado por servidor (conexiones, colas, etc.)
client.guildConnections = new Map();

// --- Cargar Handlers de Comandos ---
console.log('[HANDLER] Cargando comandos...');
const foldersPathCmd = path.join(__dirname, 'commands');
try {
    const commandFolders = fs.readdirSync(foldersPathCmd);
    for (const folder of commandFolders) {
        const commandsPath = path.join(foldersPathCmd, folder);
        if (!fs.statSync(commandsPath).isDirectory()) continue;
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            try {
                // Limpiar caché de require para recargas en caliente (si se implementa)
                // delete require.cache[require.resolve(filePath)];
                const command = require(filePath);
                if ('data' in command && 'execute' in command) {
                    client.commands.set(command.data.name, command);
                    console.log(`[+] Comando cargado: ${command.data.name}`);
                } else {
                    console.log(`[!] WARN: El comando en ${filePath} le falta "data" o "execute".`);
                }
            } catch (error) {
                console.error(`[!] ERROR cargando comando en ${filePath}:`, error);
            }
        }
    }
} catch (error) {
    console.error("[HANDLER] ERROR leyendo la carpeta de comandos:", error);
}
console.log('[HANDLER] Carga de comandos finalizada.');

// --- Cargar Handlers de Eventos ---
console.log('[HANDLER] Cargando eventos...');
const eventsPath = path.join(__dirname, 'events');
try {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        try {
             // delete require.cache[require.resolve(filePath)]; // Para recargas
            const event = require(filePath);
            if ('name' in event && 'execute' in event) {
                if (event.once) {
                    client.once(event.name, (...args) => event.execute(...args, client));
                } else {
                    // Añadir manejo de errores dentro del listener del evento
                    client.on(event.name, async (...args) => {
                         try {
                             await event.execute(...args, client);
                         } catch (error) {
                              console.error(`Error en el handler del evento ${event.name}:`, error);
                         }
                    });
                }
                console.log(`[+] Evento cargado: ${event.name}`);
            } else {
                 console.log(`[!] WARN: El evento en ${filePath} le falta "name" o "execute".`);
            }
        } catch(error) {
            console.error(`[!] ERROR cargando evento en ${filePath}:`, error);
        }
    }
} catch (error) {
     console.error("[HANDLER] ERROR leyendo la carpeta de eventos:", error);
}
console.log('[HANDLER] Carga de eventos finalizada.');

// --- Manejadores de Error Globales ---
client.on('error', error => { console.error('[ERROR Cliente Discord]:', error); });
client.on('warn', warning => { console.warn('[WARN Cliente Discord]:', warning); });
process.on('uncaughtException', (error, origin) => { console.error('[ERROR NO CAPTURADO]', error, '\nOrigen:', origin); });
process.on('unhandledRejection', (reason, promise) => { console.error('[RECHAZO PROMESA NO MANEJADO]', '\nRazón:', reason); });

// --- Iniciar Sesión ---
console.log("Iniciando sesión...");
client.login(token).catch(error => {
     console.error("[FALLO AL INICIAR SESIÓN! Verifica tu token y conexión]", error.message);
     process.exit(1);
});