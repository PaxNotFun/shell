// utils/playMusic.js
const { createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const { EmbedBuilder, Colors } = require('discord.js');
const ytdl = require('@distube/ytdl-core');

async function playMusic(guildId, songUrl, client) {
    const guildData = client.guildConnections.get(guildId);

    // Verificación robusta al inicio
    if (!guildData?.player || !guildData.connection || !songUrl || guildData.connection.state.status === 'destroyed') {
        console.error(`[playMusic:${guildId}] Abortando: Faltan datos (${!!guildData?.player}, ${!!guildData?.connection}, ${!!songUrl}) o conexión destruida (${guildData?.connection?.state?.status}).`);
        if (guildData && guildData.connection?.state.status !== 'destroyed') {
            try { guildData.connection.destroy(); } catch (e) { console.error(`[${guildId}] Error destruyendo conexión en playMusic pre-check:`, e); }
        } else if (guildData) { client.guildConnections.delete(guildId); }
        return;
    }

    const { player, lastInteraction } = guildData;

    try {
        console.log(`[playMusic:${guildId}] Iniciando stream para ${songUrl}`);
        const streamOptions = { filter: 'audioonly', quality: 'highestaudio', highWaterMark: 1 << 25 };
        const stream = ytdl(songUrl, streamOptions);

        // Prevenir crasheos si el stream falla inmediatamente o después
        stream.on('error', error => { // Cambiado a 'on' para capturar errores posteriores también, pero cuidado con loops de error
            console.error(`[ytdl Stream Error:${guildId}] URL: ${songUrl} | Error: ${error.message}`);
            // Evitar enviar múltiples mensajes si hay errores continuos
            if (!guildData.streamErrored) { // Añadir flag temporal
                 guildData.streamErrored = true;
                 const streamErrorEmbed = new EmbedBuilder().setColor(Colors.Red).setTitle('❌ Error de Stream').setDescription(`No pude obtener el audio.\n\`${error.message}\``);
                 try { lastInteraction?.followUp({ embeds: [streamErrorEmbed], ephemeral: true }); }
                 catch (notifyError) { console.error(`[${guildId}] Error notificando error de stream:`, notifyError); }
                 // Detener el player para que el listener Idle tome control
                 if (player.state.status !== AudioPlayerStatus.Idle) player.stop(true);
                 // Resetear el flag después de un tiempo por si el siguiente stream sí funciona
                 setTimeout(() => { if(guildData) guildData.streamErrored = false; }, 2000);
            }
        });

        const resource = createAudioResource(stream);
        player.play(resource);
        guildData.streamErrored = false; // Resetear flag al iniciar play
        console.log(`[playMusic:${guildId}] Recurso enviado al player.`);

    } catch (error) {
        console.error(`[playMusic:${guildId}] Error creando stream/recurso para ${songUrl}:`, error);
        const resourceErrorEmbed = new EmbedBuilder().setColor(Colors.Red).setTitle('❌ Error al Preparar Audio').setDescription(`Problema interno.\n\`${error.message}\``);
         try { lastInteraction?.followUp({ embeds: [resourceErrorEmbed], ephemeral: true }); }
         catch (notifyError) { console.error(`[${guildId}] Error notificando error de recurso:`, notifyError); }
         if (player.state.status !== AudioPlayerStatus.Idle) player.stop(true);
    }
}

module.exports = playMusic;