// deploy-commands.js
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
const { clientId, guildId, token } = require('./config.json'); // Asegúrate que config.json exista
const fs = require('node:fs');
const path = require('node:path');

const commands = [];
const foldersPath = path.join(__dirname, 'commands');

console.log("--- Registrador de Comandos Slash ---");

try {
    const commandFolders = fs.readdirSync(foldersPath);
    console.log(`Encontradas carpetas de comandos: ${commandFolders.join(', ')}`);

    for (const folder of commandFolders) {
        const commandsPath = path.join(foldersPath, folder);
        if (!fs.statSync(commandsPath).isDirectory()) continue;
        console.log(`Leyendo carpeta: ${folder}`);
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            try {
                const command = require(filePath);
                if ('data' in command && 'execute' in command) {
                    if (typeof command.data.toJSON === 'function') {
                         commands.push(command.data.toJSON());
                         console.log(`[+] Preparado: ${command.data.name}`);
                    } else {
                         console.log(`[!] WARN: La propiedad 'data' en ${file} no tiene el método toJSON() (¿es un SlashCommandBuilder?).`);
                    }
                } else {
                    console.log(`[!] WARN: El comando en ${file} le falta "data" o "execute".`);
                }
            } catch (error) {
                console.error(`[!] ERROR leyendo comando en ${filePath}:`, error);
            }
        }
    }
} catch (error) {
     console.error("!! ERROR FATAL leyendo carpetas de comandos:", error);
     process.exit(1);
}

if (commands.length === 0) {
     console.log("!! No se encontraron comandos válidos para registrar.");
     process.exit(0);
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
    try {
        console.log(`\nRefrescando ${commands.length} comandos de aplicación (/).`);
        let route;
        let mode = 'globalmente';

        if (guildId && guildId.length > 5) { // Simple check for a valid-ish ID
             console.log(`Modo de registro: Servidor específico (Guild ID: ${guildId})`);
             route = Routes.applicationGuildCommands(clientId, guildId);
             mode = `en servidor ${guildId}`;
        } else {
             console.log("Modo de registro: Global (puede tardar hasta 1 hora en actualizarse en todos los servidores).");
             route = Routes.applicationCommands(clientId);
        }

        console.log("Enviando comandos a Discord...");
        const data = await rest.put( route, { body: commands }, );

        console.log(`\n✅ ¡Registrados ${data.length} comandos ${mode} exitosamente!`);

    } catch (error) {
        console.error("\n❌ ¡ERROR AL REGISTRAR COMANDOS!:");
        if (error.rawError) {
            console.error("Datos del error:", JSON.stringify(error.rawError, null, 2));
        } else {
            console.error(error);
        }
    }
})();