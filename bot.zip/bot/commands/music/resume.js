// commands/music/resume.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('resume').setDescription('▶️ Reanuda la música pausada.'),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);

        if (!guildData?.player || !guildData.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
            const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No listo.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /resume (no listo):`, e); }
            return;
        }
        if (guildData.player.state.status !== AudioPlayerStatus.Paused) {
            const embed = new EmbedBuilder().setColor(Colors.Yellow);
             if(guildData.player.state.status === AudioPlayerStatus.Playing) embed.setDescription('ℹ️ Ya sonando.');
             else embed.setDescription('🤔 Nada pausado.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /resume (no pausado):`, e); }
            return;
        }

        try {
            const success = guildData.player.unpause();
            if (success) {
                 let note = '';
                 if (guildData.emptyChannelTimeout) { clearTimeout(guildData.emptyChannelTimeout); delete guildData.emptyChannelTimeout; note = 'Timer canal vacío cancelado.'; console.log(`[${guildId}] /resume: Cleared emptyCHTimeout.`); }
                const resumeEmbed = new EmbedBuilder().setColor(Colors.Green).setDescription('▶️ Música reanudada.');
                if (guildData.nowPlaying) resumeEmbed.addFields({ name: 'Reanudando', value: `[${guildData.nowPlaying.title}](${guildData.nowPlaying.url})`});
                if (note) resumeEmbed.setFooter({ text: note });
                 try { await interaction.reply({ embeds: [resumeEmbed] }); } // Normal reply
                 catch (e) { console.error(`[${guildId}] Err reply /resume (éxito):`, e); }
                console.log(`[${guildId}] Player resumed by ${interaction.user.tag}.`);
            } else { throw new Error('unpause() failed'); }
        } catch (error) {
            console.error(`[Resume Command Error] Guild ${guildId}:`, error);
            const errorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Error al reanudar.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
             } catch (e) { console.error(`[${guildId}] Err notify /resume error:`, e); }
        }
    },
};