// commands/music/pause.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('pause').setDescription('⏸️ Pausa la música actual.'),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);

        if (!guildData?.player || !guildData.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
            const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No listo.');
            try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /pause (no listo):`, e); }
            return;
        }
        if (guildData.player.state.status !== AudioPlayerStatus.Playing) {
            const embed = new EmbedBuilder().setColor(Colors.Yellow);
            if(guildData.player.state.status === AudioPlayerStatus.Paused) embed.setDescription('ℹ️ Ya pausado.');
            else embed.setDescription('🤔 Nada sonando.');
            try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /pause (no sonando):`, e); }
            return;
        }

        try {
            const success = guildData.player.pause();
            if (success) {
                const pauseEmbed = new EmbedBuilder().setColor(Colors.Yellow).setDescription('⏸️ Música pausada.');
                if (guildData.nowPlaying) pauseEmbed.addFields({ name: 'Pausado', value: `[${guildData.nowPlaying.title}](${guildData.nowPlaying.url})`});
                try { await interaction.reply({ embeds: [pauseEmbed] }); } // Normal reply
                catch (e) { console.error(`[${guildId}] Err reply /pause (éxito):`, e); }
                console.log(`[${guildId}] Player paused by ${interaction.user.tag}.`);
            } else { throw new Error('pause() failed'); }
        } catch (error) {
            console.error(`[Pause Command Error] Guild ${guildId}:`, error);
            const errorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Error al pausar.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
             } catch (e) { console.error(`[${guildId}] Err notify /pause error:`, e); }
        }
    },
};