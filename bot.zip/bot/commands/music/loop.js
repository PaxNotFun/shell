// commands/music/loop.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { VoiceConnectionStatus, AudioPlayerStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('loop').setDescription('🔁 Activa/desactiva loop de canción actual.')
        .addSubcommand(sub => sub.setName('activar').setDescription('✔️ Activa loop.'))
        .addSubcommand(sub => sub.setName('desactivar').setDescription('✖️ Desactiva loop.')),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);
        const subcommand = interaction.options.getSubcommand();

        if (!guildData?.player || !guildData.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
             const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No listo.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /loop (no listo):`, e); }
             return;
        }
        if (!guildData.nowPlaying) {
             const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No hay canción sonando.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /loop (no sonando):`, e); }
             return;
        }
        const playerStatus = guildData.player.state.status;
         if (playerStatus !== AudioPlayerStatus.Playing && playerStatus !== AudioPlayerStatus.Paused && playerStatus !== AudioPlayerStatus.Buffering) {
              const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription(`🤔 No puedo cambiar loop (estado: ${playerStatus}).`);
              try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /loop (estado player):`, e); }
             return;
         }

        let responseEmbed = new EmbedBuilder();
        let extraNote = ''; let cancelledTimers = false;

        try {
            if (subcommand === 'activar') {
                if (guildData.loopEnabled) { responseEmbed.setColor(Colors.Blue).setDescription('ℹ️ Loop ya activado.'); }
                else {
                    guildData.loopEnabled = true;
                    responseEmbed.setColor(Colors.Green).setDescription(`🔁 Loop **activado** para **${guildData.nowPlaying.title}**!`);
                    if (guildData.disconnectTimeout) { clearTimeout(guildData.disconnectTimeout); delete guildData.disconnectTimeout; cancelledTimers = true; }
                    if (guildData.emptyChannelTimeout) { clearTimeout(guildData.emptyChannelTimeout); delete guildData.emptyChannelTimeout; cancelledTimers = true; }
                    if (cancelledTimers) extraNote = 'Timers cancelados.';
                    if (extraNote) responseEmbed.setFooter({ text: extraNote });
                    console.log(`[${guildId}] Loop enabled by ${interaction.user.tag}.`);
                }
            } else { // desactivar
                if (!guildData.loopEnabled) { responseEmbed.setColor(Colors.Blue).setDescription('ℹ️ Loop ya desactivado.'); }
                else {
                    guildData.loopEnabled = false;
                    responseEmbed.setColor(Colors.Yellow).setDescription(`➡️ Loop **desactivado** para **${guildData.nowPlaying.title}**.`);
                    console.log(`[${guildId}] Loop disabled by ${interaction.user.tag}.`);
                }
            }
             try { await interaction.reply({ embeds: [responseEmbed] }); } // Respuesta normal
             catch (e) { console.error(`[${guildId}] Error respondiendo a /loop (éxito):`, e); }
        } catch (error) {
            console.error(`[Loop Command Error] Guild ${guildId}:`, error);
            const errorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Error al cambiar loop.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
             } catch (e) { console.error(`[${guildId}] Error notificando error en /loop:`, e); }
        }
    },
};