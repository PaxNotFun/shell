// commands/music/stop.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('stop').setDescription('⏹️ Detiene música, limpia cola y desconecta.'),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);

        if (!guildData?.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
             const embed = new EmbedBuilder().setColor(Colors.Yellow).setDescription('🤔 No estoy conectado.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } // Usar flags
             catch (e) { console.error(`[${guildId}] Error respondiendo a /stop (no conectado):`, e); }
             return;
        }

        console.log(`[${guildId}] Comando /stop recibido por ${interaction.user.tag}`);
        try {
            if (guildData.disconnectTimeout) { clearTimeout(guildData.disconnectTimeout); delete guildData.disconnectTimeout; }
            if (guildData.emptyChannelTimeout) { clearTimeout(guildData.emptyChannelTimeout); delete guildData.emptyChannelTimeout; }
            guildData.queue = [];
            guildData.nowPlaying = null;
            guildData.loopEnabled = false;
            // guildData.autoplayEnabled = false; // Ya no existe
            try { guildData.player?.stop(true); } catch(e) { console.error(`[${guildId}] Error deteniendo player en /stop:`,e); }

            if (guildData.connection.state.status !== VoiceConnectionStatus.Destroyed) {
                try { guildData.connection.destroy(); } catch (e) { console.error(`[${guildId}] Error destruyendo conexión en /stop:`, e); client.guildConnections.delete(guildId); }
            } else { client.guildConnections.delete(guildId); }

            const stoppedEmbed = new EmbedBuilder().setColor(Colors.Aqua).setDescription('⏹️ ¡Música detenida, cola limpiada y desconectado! 👋');
            try { await interaction.reply({ embeds: [stoppedEmbed] }); } // Respuesta normal (no efímera)
            catch (e) { console.error(`[${guildId}] Error respondiendo a /stop (éxito):`, e); }

        } catch (error) {
             console.error(`[Stop Command Error] Guild ${guildId}:`, error);
             const stopErrorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Ocurrió un error al intentar detener.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [stopErrorEmbed], flags: MessageFlags.Ephemeral }); // Usar flags
                 else await interaction.followUp({ embeds: [stopErrorEmbed], flags: MessageFlags.Ephemeral }); // Usar flags
             } catch (e) { console.error(`[${guildId}] Error notificando error en /stop:`, e); }
             // Limpieza de emergencia
             try {
                 if (guildData?.connection && guildData.connection.state.status !== VoiceConnectionStatus.Destroyed) guildData.connection.destroy();
                 client.guildConnections.delete(guildId);
             } catch(cleanupError) { console.error(`[${guildId}] Error limpieza emergencia /stop:`, cleanupError); client.guildConnections.delete(guildId); }
        }
    },
};