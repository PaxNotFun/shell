// commands/music/skip.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('skip').setDescription('⏭️ Salta la canción actual.'),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);

        if (!guildData?.player || !guildData.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
            const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No estoy listo.');
            try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /skip (no listo):`, e); }
            return;
        }
        if (!guildData.nowPlaying) {
            const embed = new EmbedBuilder().setColor(Colors.Yellow).setDescription('🤔 No hay nada sonando.');
            try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /skip (nada sonando):`, e); }
            return;
        }

        try {
            const skippedSong = guildData.nowPlaying;
            console.log(`[${guildId}] Skipping: ${skippedSong.title} (by ${interaction.user.tag})`);
            guildData.loopEnabled = false; // Desactivar loop al saltar
            guildData.player.stop(true); // Dispara 'Idle'

            const skipEmbed = new EmbedBuilder().setColor(Colors.Blue).setTitle('⏭️ Canción Saltada')
                .setDescription(`Se saltó: [**${skippedSong.title}**](${skippedSong.url})`)
                .addFields({ name: 'Pedido por', value: interaction.user.toString(), inline: true }).setTimestamp();
             if (guildData.queue.length > 0) skipEmbed.setFooter({ text: `Siguiente: ${guildData.queue[0].title}` });
             else skipEmbed.setFooter({ text: 'Cola vacía.' });

            try { await interaction.reply({ embeds: [skipEmbed] }); } // Respuesta normal
            catch (e) { console.error(`[${guildId}] Err reply /skip (éxito):`, e); }

        } catch (error) {
            console.error(`[Skip Command Error] Guild ${guildId}:`, error);
            const errorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Error al saltar.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
             } catch (e) { console.error(`[${guildId}] Err notify /skip error:`, e); }
        }
    },
};