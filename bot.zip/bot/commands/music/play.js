// commands/music/play.js
const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, Colors, PermissionsBitField, ChannelType, MessageFlags } = require('discord.js'); // Asegurar MessageFlags
const { joinVoiceChannel, createAudioPlayer, AudioPlayerStatus, entersState, VoiceConnectionStatus, NoSubscriberBehavior } = require('@discordjs/voice');
const ytSearch = require('yt-search'); // Volvemos a usar yt-search
const ytdl = require('@distube/ytdl-core'); // Volvemos a usar ytdl-core
const playMusic = require('../../utils/playMusic'); // Asegúrate que la ruta sea correcta y que playMusic use ytdl

// Helper para formatear duración
function formatDuration(seconds) {
    if (typeof seconds !== 'number' || isNaN(seconds) || seconds <= 0) return 'N/A';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    let str = '';
    if (hours > 0) str += `${hours}:`;
    str += `${minutes.toString().padStart(hours > 0 ? 2 : 1, '0')}:`;
    str += `${secs.toString().padStart(2, '0')}`;
    return str;
}

// Helper para parsear timestamps tipo "1:23" (útil para yt-search)
function parseTimestamp(timestamp) {
    if (!timestamp || typeof timestamp !== 'string') return 0;
    const parts = timestamp.split(':').map(Number).filter(n => !isNaN(n));
    let seconds = 0;
    if (parts.length === 3) { seconds += parts[0] * 3600; seconds += parts[1] * 60; seconds += parts[2]; }
    else if (parts.length === 2) { seconds += parts[0] * 60; seconds += parts[1]; }
    else if (parts.length === 1) { seconds += parts[0]; }
    return seconds > 0 ? seconds : 0;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('🎶 Añade una canción a la cola (o la reproduce si está vacía).')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('🔗 La URL de YouTube o el término de búsqueda.')
                .setRequired(true)),

    async execute(interaction, client) {
        const query = interaction.options.getString('query');
        const voiceChannel = interaction.member?.voice?.channel;
        const guildId = interaction.guildId;
        const userId = interaction.user.tag;

        // --- 1. Verificaciones iniciales ---
        if (!voiceChannel) {
            const embed = new EmbedBuilder().setColor(Colors.Red).setDescription('❌ ¡Debes estar en un canal de voz!');
            try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply play (no VC):`, e); }
            return;
        }
        if (voiceChannel.type !== ChannelType.GuildVoice && voiceChannel.type !== ChannelType.GuildStageVoice) {
             const embed = new EmbedBuilder().setColor(Colors.Red).setDescription('❌ Solo me uno a canales de voz/escenario.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply play (VC type):`, e); }
             return;
        }

        // --- 2. Verificar Permisos del Bot ---
        let botPermissions;
         try { botPermissions = voiceChannel.permissionsFor(interaction.guild.members.me); }
         catch (permError) {
              console.error(`[${guildId}] Err getting perms for Chan ${voiceChannel.id}:`, permError);
              const embed = new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Err verificando permisos para '${voiceChannel.name}'.`);
              try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral });
              } catch(e) { console.error("Err reply perm check fail:", e); }
             return;
         }
        const requiredPerms = [ { flag: PermissionsBitField.Flags.Connect, name: 'Conectarme' }, { flag: PermissionsBitField.Flags.Speak, name: 'Hablar' }, { flag: PermissionsBitField.Flags.ViewChannel, name: 'Ver Canal' }];
        const missingPerms = requiredPerms.filter(perm => !botPermissions?.has(perm.flag));
        if (missingPerms.length > 0) {
             const embed = new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No tengo permiso para **${missingPerms.map(p=>p.name).join(', ')}** en '${voiceChannel.name}'.`);
              try {
                if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
                else await interaction.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral });
            } catch(e){ console.error("Err reply missing perms:",e); }
             return;
        }

        // --- 3. Defer Reply e Indicador de Búsqueda ---
        const searchingEmbed = new EmbedBuilder().setColor(Colors.Yellow).setDescription(`🔍 Buscando "${query}"...`);
        try {
            if (!interaction.replied && !interaction.deferred) {
                 await interaction.deferReply();
                 await interaction.editReply({ embeds: [searchingEmbed] });
            }
        } catch (error) {
            console.error(`[${guildId}] Error en deferReply/editReply inicial:`, error);
            // No intentar responder aquí si defer falló, el catch en interactionCreate lo manejará
            return;
        }

        // --- 4. Procesar Query y obtener datos del video (Usando yt-search y ytdl-core) ---
        let songUrl = query; let videoData = null; const youtubeUrlRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})([\?&].*)?$/;
        try {
            if (!youtubeUrlRegex.test(query)) { // Búsqueda con yt-search
                const result = await ytSearch(query);
                if (!result?.videos?.length) throw new Error('No se encontraron resultados.');
                videoData = result.videos[0]; songUrl = videoData.url;
                if (!songUrl) throw new Error('No se pudo obtener URL del video.');
                // Parsear duración de yt-search si existe
                if (videoData.seconds) videoData.timestamp = formatDuration(videoData.seconds);
                else if (videoData.timestamp) videoData.timestamp = formatDuration(parseTimestamp(videoData.timestamp));
                else videoData.timestamp = 'N/A'; // Poner N/A si no hay info

            } else { // Es URL, validar y obtener info con ytdl-core
                 if (!ytdl.validateURL(songUrl)) throw new Error('URL de YouTube inválida.');
                 const basicInfo = await ytdl.getBasicInfo(songUrl);
                 videoData = {
                     title: basicInfo.videoDetails.title,
                     thumbnail: basicInfo.videoDetails.thumbnails?.[0]?.url,
                     url: songUrl,
                     timestamp: formatDuration(parseInt(basicInfo.videoDetails.lengthSeconds, 10)),
                     author: { name: basicInfo.videoDetails.ownerChannelName || 'Desconocido' }
                     // Nota: yt-search devuelve author.name, ytdl devuelve ownerChannelName
                 };
            }
        } catch (searchOrInfoError) {
             console.error(`[${guildId}] Error buscando/obteniendo info para "${query}" (yt-search/ytdl):`, searchOrInfoError);
             const fetchErrorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Hubo un error obteniendo info: ${searchOrInfoError.message}`);
             try { await interaction.editReply({ embeds: [fetchErrorEmbed] }); } catch(e){ console.error("Err editReply fetch fail:", e); }
             return;
        }

        // --- 5. Crear objeto 'song' ---
        const song = { url: songUrl, title: videoData?.title || 'Título Desconocido', thumbnail: videoData?.thumbnail, duration: videoData?.timestamp || 'N/A', requester: userId };

        // --- 6. Obtener/Crear datos del servidor ---
        let guildData = client.guildConnections.get(guildId);

        // --- 7. Cancelar Timeouts Pendientes ---
        if (guildData?.disconnectTimeout) { clearTimeout(guildData.disconnectTimeout); delete guildData.disconnectTimeout; console.log(`[${guildId}] Play: Cleared disconnectTimeout.`); }
        if (guildData?.emptyChannelTimeout) { clearTimeout(guildData.emptyChannelTimeout); delete guildData.emptyChannelTimeout; console.log(`[${guildId}] Play: Cleared emptyChannelTimeout.`); if(guildData.player?.state.status === AudioPlayerStatus.Paused) { try { guildData.player.unpause(); console.log(`[${guildId}] Play: Resuming player.`); } catch(e){ console.error("Err unpausing:",e); } } }

        // --- 8. Crear Conexión/Player si no existen ---
        if (!guildData) {
            try {
                const connection = joinVoiceChannel({ channelId: voiceChannel.id, guildId: guildId, adapterCreator: interaction.guild.voiceAdapterCreator, selfDeaf: true });
                await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
                const player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Play }});
                connection.subscribe(player);

                guildData = { // Inicialización SIN autoplayEnabled
                    connection: connection, player: player, queue: [], nowPlaying: null,
                    lastInteraction: interaction, disconnectTimeout: null, emptyChannelTimeout: null,
                    loopEnabled: false
                };
                client.guildConnections.set(guildId, guildData);
                console.log(`[${guildId}] Nueva conexión/player/guildData creados.`);

                // --- MANEJADORES DE EVENTOS ---
                connection.on(VoiceConnectionStatus.Disconnected, async () => {
                    console.log(`[${guildId}] VC Disconnected.`);
                    const currentData = client.guildConnections.get(guildId);
                    try { await Promise.race([ entersState(connection, VoiceConnectionStatus.Signalling, 5_000), entersState(connection, VoiceConnectionStatus.Connecting, 5_000) ]); }
                    catch (error) { if (connection.state.status !== VoiceConnectionStatus.Destroyed) { console.log(`[${guildId}] VC Disconnected permanently.`); if (currentData?.disconnectTimeout) clearTimeout(currentData.disconnectTimeout); if (currentData?.emptyChannelTimeout) clearTimeout(currentData.emptyChannelTimeout); try { connection.destroy(); } catch(e) { console.error("Err destroy VCD:",e); } } }
                });
                connection.on(VoiceConnectionStatus.Destroyed, () => {
                    console.log(`[${guildId}] VC Destroyed.`);
                    const currentData = client.guildConnections.get(guildId);
                    if (currentData?.disconnectTimeout) clearTimeout(currentData.disconnectTimeout);
                    if (currentData?.emptyChannelTimeout) clearTimeout(currentData.emptyChannelTimeout);
                    try { currentData?.player?.stop(true); } catch(e){ console.error("Err stop VCD:",e); }
                    client.guildConnections.delete(guildId);
                    console.log(`[${guildId}] guildData cleaned (Destroyed).`);
                });
                player.on(AudioPlayerStatus.Idle, async () => {
                    console.log(`[${guildId}] Player Idle.`);
                    const currentGuildDataOnIdle = client.guildConnections.get(guildId);
                    if (!currentGuildDataOnIdle?.connection || currentGuildDataOnIdle.connection.state.status === VoiceConnectionStatus.Destroyed) return;
                    const lastPlayed = currentGuildDataOnIdle.nowPlaying;
                    currentGuildDataOnIdle.nowPlaying = null;
                    if (currentGuildDataOnIdle.loopEnabled && lastPlayed) {
                        console.log(`[${guildId}] Idle: Loop, replaying.`); currentGuildDataOnIdle.nowPlaying = lastPlayed; playMusic(guildId, lastPlayed.url, client);
                    } else if (currentGuildDataOnIdle.queue.length > 0) {
                        console.log(`[${guildId}] Idle: Playing next.`); const nextSong = currentGuildDataOnIdle.queue.shift(); currentGuildDataOnIdle.nowPlaying = nextSong; playMusic(guildId, nextSong.url, client);
                        const embed = new EmbedBuilder().setColor(Colors.Green).setTitle("🎵 Reproduciendo Siguiente").setDescription(`[**${nextSong.title}**](${nextSong.url})`).addFields({ name: 'Por', value: nextSong.requester, inline: true }).setTimestamp(); if(nextSong.thumbnail) embed.setThumbnail(nextSong.thumbnail);
                        try { await currentGuildDataOnIdle.lastInteraction?.channel?.send({ embeds: [embed] }); } catch(e){ console.error(`[${guildId}] Err send next song:`, e); }
                        if (currentGuildDataOnIdle.disconnectTimeout) { clearTimeout(currentGuildDataOnIdle.disconnectTimeout); delete currentGuildDataOnIdle.disconnectTimeout; }
                    } else { console.log(`[${guildId}] Idle: Queue empty, scheduling disconnect.`); scheduleDisconnect(currentGuildDataOnIdle, client); }
                });
                player.on('error', error => {
                    console.error(`[AudioPlayer Error ${guildId}]:`, error);
                    const currentData = client.guildConnections.get(guildId); const embed = new EmbedBuilder().setColor(Colors.Red).setDescription(`⚠️ **Error Player:** ${error.message || '?'}`);
                    try{ currentData?.lastInteraction?.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch(e){ console.error("Err notify player error:",e); }
                    if (currentData?.disconnectTimeout) clearTimeout(currentData.disconnectTimeout); if (currentData?.emptyChannelTimeout) clearTimeout(currentData.emptyChannelTimeout);
                    try{ currentData?.connection?.destroy(); } catch(e){ console.error("Err destroy on player error:",e); client.guildConnections.delete(guildId); }
                });

            } catch (connectionError) {
                console.error(`[${guildId}] Error crítico uniéndose/estableciendo conexión:`, connectionError);
                 client.guildConnections.delete(guildId);
                 const joinErrorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No pude unirme al canal: ${connectionError.message}`);
                 try { await interaction.editReply({ embeds: [joinErrorEmbed] }); } catch (editError) { console.error("Err editReply conn fail:", editError); }
                 return;
            }
        } else {
            // --- 9. Lógica si ya existe una conexión ---
            console.log(`[${guildId}] Usando conexión/player existentes.`);
            guildData.lastInteraction = interaction;
            if (guildData.connection.state.status === VoiceConnectionStatus.Destroyed || guildData.connection.state.status === VoiceConnectionStatus.Disconnected) {
                console.log(`[${guildId}] Conn existente ${guildData.connection.state.status}. Limpiando.`);
                 if (guildData.disconnectTimeout) clearTimeout(guildData.disconnectTimeout); if (guildData.emptyChannelTimeout) clearTimeout(guildData.emptyChannelTimeout);
                 client.guildConnections.delete(guildId);
                const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('⚠️ Problema con conexión anterior. Intenta de nuevo.');
                try { await interaction.editReply({ embeds: [embed] }); } catch(e){ console.error("Err editReply conn problem:", e); }
                return;
            }
            if (guildData.connection.joinConfig.channelId !== voiceChannel.id) {
                const embed = new EmbedBuilder().setColor(Colors.Yellow).setDescription(`🤔 Estoy en otro canal (\`${interaction.guild.channels.cache.get(guildData.connection.joinConfig.channelId)?.name ?? '?'}\`).`);
                try { await interaction.editReply({ embeds: [embed] }); } catch(e){ console.error("Err editReply wrong chan:", e); }
                return;
            }
            // Asegurar propiedades existen
            if (!guildData.queue) guildData.queue = []; if (typeof guildData.nowPlaying === 'undefined') guildData.nowPlaying = null; if (typeof guildData.loopEnabled === 'undefined') guildData.loopEnabled = false; if (typeof guildData.emptyChannelTimeout === 'undefined') guildData.emptyChannelTimeout = null; if (typeof guildData.disconnectTimeout === 'undefined') guildData.disconnectTimeout = null;
        }

        // --- 10. Re-verificar guildData antes de usarlo (Fix TypeError) ---
        guildData = client.guildConnections.get(guildId);
        if (!guildData) {
            console.log(`[${guildId}] guildData desapareció antes de play/queue.`);
            const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription("⚠️ Sesión terminada inesperadamente.");
             try { await interaction.editReply({ embeds: [embed] }); }
             catch (e) { try { await interaction.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e2) { console.error("Err notify guildData disappearance:", e2); } }
            return;
        }

        // --- 11. Decidir si reproducir ahora o añadir a la cola ---
        // AñadirRobustez: Verificar player existe antes de acceder a state
        const playerIsIdle = guildData.player?.state?.status === AudioPlayerStatus.Idle;
        if (!guildData.nowPlaying && playerIsIdle) {
             // --- Reproducir Inmediatamente ---
             console.log(`[${guildId}] Player idle, play now: ${song.title}`);
             guildData.nowPlaying = song;
             try {
                 playMusic(guildId, song.url, client); // Iniciar música
                 const playingEmbed = new EmbedBuilder().setColor(Colors.Green).setTitle('▶️ Reproduciendo Ahora')
                     .setDescription(`[**${song.title}**](${song.url})`)
                     .addFields( { name: 'Solicitado por', value: song.requester, inline: true }, ...(song.duration && song.duration !== 'N/A' ? [{ name: 'Duración', value: song.duration, inline: true }] : []) )
                     .setTimestamp();
                 if (song.thumbnail) playingEmbed.setThumbnail(song.thumbnail);
                 try { await interaction.editReply({ embeds: [playingEmbed] }); } catch (e) { console.error(`[${guildId}] Err editReply playingNow:`, e); }
             } catch (playError) {
                  console.error(`[${guildId}] Err trying to play immediately:`, playError);
                  const embed = new EmbedBuilder().setColor(Colors.Red).setDescription('❌ Error al iniciar reproducción.');
                  guildData.nowPlaying = null;
                   try { await interaction.editReply({ embeds: [embed] }); } catch(e) { console.error("Err editReply playStartFail:", e); }
             }
        } else {
             // --- Añadir a la Cola ---
             if (!guildData.queue) guildData.queue = [];
             guildData.queue.push(song);
             console.log(`[${guildId}] Added to queue: ${song.title}. Length: ${guildData.queue.length}`);
             const queuedEmbed = new EmbedBuilder().setColor(Colors.Blue).setAuthor({ name: "Añadido a la cola" })
                 .setDescription(`[**${song.title}**](${song.url})`)
                 .addFields( { name: 'Posición', value: `${guildData.queue.length}`, inline: true }, ...(song.duration && song.duration !== 'N/A' ? [{ name: 'Duración', value: song.duration, inline: true }] : []), { name: 'Solicitado por', value: song.requester, inline: true } )
                 .setTimestamp();
             if (song.thumbnail) queuedEmbed.setThumbnail(song.thumbnail);
             try { await interaction.editReply({ embeds: [queuedEmbed] }); } catch (e) { console.error(`[${guildId}] Err editReply queued:`, e); }
        }
    }, // Fin execute
}; // Fin module.exports


// --- Función Auxiliar para Programar Desconexión (al final del archivo) ---
function scheduleDisconnect(guildData, client) {
    if (!guildData?.connection || guildData.connection.state.status === 'destroyed') return;
    const guildId = guildData.connection.joinConfig.guildId;

    if (!guildData.disconnectTimeout && !guildData.emptyChannelTimeout) {
        console.log(`[${guildId}] Scheduling disconnect timer (10s)...`);
        const disconnectEmbed = new EmbedBuilder()
            .setColor(Colors.Aqua)
            // .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() }) // Eliminado por error de validación
            .setDescription(`🏁 Fin de la cola.\nMe desconectaré en **10 segundos**.`)
            .setTimestamp();
        try {
             guildData.lastInteraction?.channel?.send({ embeds: [disconnectEmbed] })
                .then(msg => setTimeout(() => msg?.delete().catch(()=>{}), 11_000))
                .catch(e => console.error(`[${guildId}] Err send disconnect warn:`, e));
        } catch (e) { console.error(`[${guildId}] Err sending disconnect warn outside promise:`, e); }

        guildData.disconnectTimeout = setTimeout(async () => {
            const latestGuildData = client.guildConnections.get(guildId);
            if (!latestGuildData) return;
            let cleanupPerformed = false;
            try {
                 const isIdle = latestGuildData.player?.state.status === AudioPlayerStatus.Idle;
                 const isConnected = latestGuildData.connection?.state.status !== VoiceConnectionStatus.Destroyed;
                if (isIdle && isConnected) {
                     console.log(`[${guildId}] Executing scheduled disconnect (no activity).`);
                     const goodbyeEmbed = new EmbedBuilder().setColor(Colors.Grey).setDescription("👋 Desconectando...");
                     try { await latestGuildData.lastInteraction?.channel?.send({ embeds: [goodbyeEmbed] }); } catch { /* Ignorar */ }
                     try { latestGuildData.connection.destroy(); cleanupPerformed = true; } // Marcar si destroy se llama
                     catch(e){ console.error(`[${guildId}] Err destroy conn (timeout):`, e); }
                } else { console.log(`[${guildId}] Scheduled disconnect cancelled. Idle: ${isIdle}, Connected: ${isConnected}`); }
            } catch(timeoutError) { console.error(`[${guildId}] Error dentro del timeout de scheduleDisconnect:`, timeoutError); }
            finally {
                // Limpiar mapa y timeout solo si no lo hizo el listener 'Destroyed'
                 if (client.guildConnections.has(guildId)) {
                    const finalData = client.guildConnections.get(guildId);
                     if (finalData) delete finalData.disconnectTimeout; // Borrar referencia al timer
                     // No borrar del mapa aquí si destroy() se llamó, confiar en 'Destroyed'
                     if (cleanupPerformed) client.guildConnections.delete(guildId); // Borrar solo si destroy se llamó aquí
                 }
            }
        }, 10_000);
    } else {
         if(guildData.disconnectTimeout) console.log(`[${guildId}] Disconnect schedule requested, but disconnectTimeout active.`);
         if(guildData.emptyChannelTimeout) console.log(`[${guildId}] Disconnect schedule requested, but emptyChannelTimeout active.`);
    }
}