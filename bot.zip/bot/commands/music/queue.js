// commands/music/queue.js
const { SlashCommandBuilder, EmbedBuilder, Colors, MessageFlags } = require('discord.js'); // Añadir MessageFlags
const { VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    data: new SlashCommandBuilder().setName('queue').setDescription(' Muestra la cola de canciones actual.'),
    async execute(interaction, client) {
        const guildId = interaction.guildId;
        const guildData = client.guildConnections.get(guildId);

        if (!guildData?.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
             const embed = new EmbedBuilder().setColor(Colors.Orange).setDescription('🤔 No estoy conectado.');
             try { await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }); } catch (e) { console.error(`[${guildId}] Err reply /queue (no conectado):`, e); }
             return;
        }

        const nowPlaying = guildData.nowPlaying;
        const queue = guildData.queue || [];

        try {
            const queueEmbed = new EmbedBuilder().setColor(Colors.Purple).setTitle('🎶 Cola de Reproducción').setTimestamp();

            if (nowPlaying) {
                queueEmbed.addFields({ name: '▶️ Sonando', value: `[**${nowPlaying.title}**](${nowPlaying.url})\n\`Dur: ${nowPlaying.duration} | Por: ${nowPlaying.requester}\`` });
                if(nowPlaying.thumbnail) queueEmbed.setThumbnail(nowPlaying.thumbnail);
            } else { queueEmbed.addFields({ name: '▶️ Sonando', value: '😴 Nada...' }); }

            if (queue.length > 0) {
                const displayLimit = 10;
                const queueString = queue.slice(0, displayLimit).map((song, index) => {
                    return `\`${index + 1}.\` [${song.title}](${song.url})\n\`Dur: ${song.duration} | Por: ${song.requester}\``;
                }).join('\n\n') || '\u200B'; // Usar Zero Width Space si está vacío
                queueEmbed.addFields({ name: `⬇️ Próximas (${queue.length})`, value: queueString.substring(0, 1020) });
                if (queue.length > displayLimit) queueEmbed.addFields({ name: '...', value: `... y ${queue.length - displayLimit} más.` });
            } else { queueEmbed.addFields({ name: '⬇️ Próximas', value: '¡Vacía!' }); }

            queueEmbed.setFooter({ text: `En cola: ${queue.length} | Loop: ${guildData.loopEnabled ? 'Activado' : 'Off'}` }); // Removido Autoplay

            try { await interaction.reply({ embeds: [queueEmbed] }); } // Respuesta normal
            catch (e) { console.error(`[${guildId}] Err reply /queue (éxito):`, e); }

        } catch (error) {
             console.error(`[Queue Command Error] Guild ${guildId}:`, error);
             const errorEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription('⚠️ Error al generar cola.');
             try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
                 else await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
             } catch (e) { console.error(`[${guildId}] Err notify /queue error:`, e); }
        }
    },
};