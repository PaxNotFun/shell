// events/ready.js
const { Events, ActivityType } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        try {
             if (!client.user) {
                 console.error("Error en Ready: client.user es null.");
                 return;
             }
             console.log(`\n✅ Bot listo! Loggeado como ${client.user.tag} (ID: ${client.user.id})`);
             client.user.setActivity('música | /play', { type: ActivityType.Listening });
             console.log(`🔷 Activo en ${client.guilds.cache.size} servidor(es).`);
             console.log(`🔷 ${client.commands.size} comandos cargados.`);
        } catch (error) {
             console.error("!! Error en el evento ClientReady:", error);
        }
    },
};