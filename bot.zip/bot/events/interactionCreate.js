// events/interactionCreate.js
const { Events, EmbedBuilder, Colors, DiscordAPIError, InteractionType } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // Ignorar si no es un comando slash del chat
        if (interaction.type !== InteractionType.ApplicationCommand || !interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        const guildId = interaction.guildId || 'DM'; // Handle DM interactions gracefully if needed
        const userId = interaction.user.tag;

        if (!command) {
            console.error(`Comando no encontrado: ${interaction.commandName} (User: ${userId}, Guild: ${guildId})`);
            const noCommandEmbed = new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Comando desconocido: \`/${interaction.commandName}\`.`);
            try {
                 if (!interaction.replied && !interaction.deferred) await interaction.reply({ embeds: [noCommandEmbed], ephemeral: true });
                 else await interaction.followUp({ embeds: [noCommandEmbed], ephemeral: true }).catch(() => {}); // Ignorar error si followUp falla aquí
            } catch (replyError) { console.error(`[${guildId}] Error respondiendo comando no encontrado:`, replyError); }
            return;
        }

        // --- Ejecución del Comando y Manejo Principal de Errores ---
        try {
            // Log detallado de ejecución
            console.log(`[${guildId}] CMD: /${interaction.commandName} | Args: ${JSON.stringify(interaction.options.data)} | User: ${userId}`);
            await command.execute(interaction, client);

        } catch (error) {
            console.error(`[ERROR Ejecución /${interaction.commandName}] Guild: ${guildId} | User: ${userId}:`, error);
            const errorEmbed = new EmbedBuilder()
                .setColor(Colors.Red).setTitle('💥 Error Inesperado')
                .setDescription(`¡Ups! Hubo un problema al procesar \`/${interaction.commandName}\`.\n*Intenta de nuevo más tarde.*`)
                .setTimestamp();
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral }); // Usar flags
                } else {
                    await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral }); // Usar flags
                }
            } catch (replyError) {
                console.error(`[${guildId}] FALLO AL NOTIFICAR ERROR en canal ${interaction.channelId} para /${interaction.commandName}. Error original: ${error.message}. Error notificación:`, replyError);
            }
        }
    },
};