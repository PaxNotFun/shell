// events/guildDelete.js
const { Events } = require('discord.js');
const { VoiceConnectionStatus } = require('@discordjs/voice');

module.exports = {
    name: Events.GuildDelete,
    execute(guild, client) {
        console.log(`Evento GuildDelete: ${guild?.name || 'Nombre Desconocido'} (ID: ${guild?.id})`);
        const guildId = guild?.id;
        if (!guildId) return; // Salir si no podemos obtener el ID

        const guildData = client.guildConnections.get(guildId);

        if (guildData) {
            console.log(`Limpiando datos para ${guildId} (GuildDelete)...`);
            try {
                if (guildData.disconnectTimeout) clearTimeout(guildData.disconnectTimeout);
                if (guildData.emptyChannelTimeout) clearTimeout(guildData.emptyChannelTimeout);
                 if (guildData.connection && guildData.connection.state.status !== VoiceConnectionStatus.Destroyed) {
                     try { guildData.connection.destroy(); }
                     catch (destroyError) { console.error(`[${guildId}] Error destruyendo conexión (guildDelete):`, destroyError); }
                 }
                client.guildConnections.delete(guildId); // Asegurar borrado del mapa
                console.log(`Datos para ${guildId} limpiados OK (GuildDelete).`);
            } catch (cleanupError) {
                 console.error(`[${guildId}] Error durante limpieza (guildDelete):`, cleanupError);
                 client.guildConnections.delete(guildId);
            }
        } else {
             // console.log(`No se encontraron datos para limpiar (GuildDelete): ${guildId}.`); // Log opcional
        }
    },
};