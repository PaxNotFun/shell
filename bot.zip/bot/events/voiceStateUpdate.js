// events/voiceStateUpdate.js
const { Events, EmbedBuilder, Colors, ChannelType, MessageFlags } = require('discord.js'); // Añadir MessageFlags por si se usan en embeds
const { AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');

// Tiempo en milisegundos para esperar antes de desconectar (60 segundos)
const EMPTY_CHANNEL_TIMEOUT = 60 * 1000;

module.exports = {
    name: Events.VoiceStateUpdate,
    // 'oldState' = estado antes del cambio, 'newState' = estado después del cambio
    async execute(oldState, newState, client) {
        const guildId = newState.guild.id || oldState.guild.id; // ID del servidor
        const guildData = client.guildConnections.get(guildId); // Buscar datos de este servidor

        // --- 1. Ignorar si el bot no tiene conexión activa en este servidor ---
        if (!guildData?.connection || guildData.connection.state.status === VoiceConnectionStatus.Destroyed) {
            // El bot no está conectado o la conexión ya fue destruida, no hacer nada.
            return;
        }

        const botChannelId = guildData.connection.joinConfig.channelId; // ID del canal donde está el bot

        // --- 2. Determinar si el evento es relevante para el canal del bot ---
        let isRelevant = false;
        // Alguien (o el bot) salió del canal del bot
        if (oldState.channelId === botChannelId && newState.channelId !== botChannelId) isRelevant = true;
        // Alguien (o el bot) entró al canal del bot
        else if (newState.channelId === botChannelId && oldState.channelId !== botChannelId) isRelevant = true;
        // Alguien (NO el bot) cambió estado DENTRO del canal (mute, stream, etc.) - Reevaluar conteo
        else if (newState.channelId === botChannelId && oldState.channelId === botChannelId && newState.id !== client.user.id) isRelevant = true;

        if (!isRelevant) {
             // El evento no afecta directamente la presencia en el canal del bot, ignorar.
            return;
        }

        // --- 3. Obtener el canal de voz y contar miembros humanos ---
        let voiceChannel;
        let humanMembers = -1; // Iniciar con -1 para indicar error si no se puede contar
        try {
            voiceChannel = await client.channels.fetch(botChannelId);
             if (!voiceChannel || (voiceChannel.type !== ChannelType.GuildVoice && voiceChannel.type !== ChannelType.GuildStageVoice)) {
                throw new Error('Canal no encontrado o tipo inválido.');
            }
            // Contar miembros que NO sean bots
            humanMembers = voiceChannel.members.filter(member => !member.user.bot).size;
            // console.log(`[${guildId}] VSU Check: Canal ${voiceChannel.name}, Humanos = ${humanMembers}`); // Log de depuración opcional

        } catch (fetchError) {
            console.error(`[${guildId}] VSU: Error obteniendo canal ${botChannelId} o miembros:`, fetchError);
            // Si no podemos verificar el canal, es más seguro desconectar por si acaso
            if (guildData.connection?.state.status !== VoiceConnectionStatus.Destroyed) {
                 try { guildData.connection.destroy(); } catch(e){console.error(`[${guildId}] Err destroy VSU fetch fail:`, e);}
            }
            // Ya que no podemos obtener el canal, no continuamos con la lógica de pausa/reanudación
            return;
        }

        // Si humanMembers sigue siendo -1, algo falló en el conteo, no continuar.
        if (humanMembers === -1) {
             console.error(`[${guildId}] VSU: No se pudo determinar el número de miembros humanos.`);
             return;
        }


        // --- 4. Lógica Principal: Pausar/Reanudar/Desconectar ---
        try {
            if (humanMembers === 0) {
                // --- CANAL VACÍO ---
                const playerStatus = guildData.player?.state.status;
                // Solo actuar si está reproduciendo/pausado Y no hay ya un timer de canal vacío corriendo
                if ((playerStatus === AudioPlayerStatus.Playing || playerStatus === AudioPlayerStatus.Paused) && !guildData.emptyChannelTimeout) {

                    // Pausar si estaba reproduciendo
                    if (playerStatus === AudioPlayerStatus.Playing) {
                         try {
                             if (guildData.player.pause()) console.log(`[${guildId}] VSU: Auto-pausado por canal vacío.`);
                             else console.warn(`[${guildId}] VSU: player.pause() devolvió false.`);
                         } catch(e){ console.error(`[${guildId}] VSU: Error en player.pause():`,e); }
                    }

                    // Anunciar y programar desconexión
                    console.log(`[${guildId}] VSU: Iniciando timer de desconexión por canal vacío (${EMPTY_CHANNEL_TIMEOUT/1000}s).`);
                    const pauseEmbed = new EmbedBuilder().setColor(Colors.Orange).setDescription(`⏸️ Canal vacío, música pausada. Me desconectaré en **${EMPTY_CHANNEL_TIMEOUT / 1000} segundos**.`);
                    try {
                         // Intentar enviar al canal de la última interacción (puede fallar si el canal fue borrado, etc.)
                         await guildData.lastInteraction?.channel?.send({ embeds: [pauseEmbed] });
                    } catch (e) { console.error(`[${guildId}] VSU: Error enviando embed de auto-pausa:`, e); }

                    // Programar la desconexión
                    guildData.emptyChannelTimeout = setTimeout(async () => {
                        const latestGuildData = client.guildConnections.get(guildId);
                        if (!latestGuildData) return; // Bot ya desconectado/limpiado
                        let currentVC; let latestHumans = 0;
                         try { // Re-verificar miembros justo antes de desconectar
                            currentVC = await client.channels.fetch(botChannelId);
                            if(currentVC && currentVC.members) latestHumans = currentVC.members.filter(m => !m.user.bot).size; else latestHumans = -1;
                         } catch { latestHumans = -1; }

                        // Solo desconectar si SIGUE vacío y la conexión existe
                        if (latestHumans === 0 && latestGuildData.connection?.state.status !== VoiceConnectionStatus.Destroyed) {
                            console.log(`[${guildId}] VSU: Timeout canal vacío alcanzado. Desconectando.`);
                            const goodbyeEmbed = new EmbedBuilder().setColor(Colors.Grey).setDescription("👋 Desconectando por inactividad.");
                             try { await latestGuildData.lastInteraction?.channel?.send({ embeds: [goodbyeEmbed] }); } catch { /* Ignorar si no se puede enviar */ }
                             // Intentar destruir la conexión
                             try { latestGuildData.connection.destroy(); } catch(e){ console.error(`[${guildId}] VSU: Err destroy conn (timeout):`,e); client.guildConnections.delete(guildId); } // Limpiar mapa si destroy falla
                        } else {
                            console.log(`[${guildId}] VSU: Timeout canal vacío cancelado (actividad o conexión inválida). Humanos=${latestHumans}, Estado=${latestGuildData.connection?.state.status}`);
                        }
                        // Limpiar la referencia al timeout en guildData si aún existe en el mapa
                        const checkData = client.guildConnections.get(guildId);
                        if (checkData) delete checkData.emptyChannelTimeout;

                    }, EMPTY_CHANNEL_TIMEOUT);
                }
            } else { // humanMembers > 0
                // --- HAY HUMANOS ---
                // Cancelar el timer de desconexión por canal vacío si estaba activo
                if (guildData.emptyChannelTimeout) {
                    console.log(`[${guildId}] VSU: Actividad detectada, cancelando timeout de canal vacío.`);
                    clearTimeout(guildData.emptyChannelTimeout);
                    delete guildData.emptyChannelTimeout;

                    // Reanudar si estaba pausado por el bot
                    if (guildData.player?.state.status === AudioPlayerStatus.Paused) {
                         try {
                             if (guildData.player.unpause()) { // Verificar si reanudó bien
                                 console.log(`[${guildId}] VSU: Reanudando player automáticamente.`);
                                 const resumeEmbed = new EmbedBuilder().setColor(Colors.Green).setDescription(`▶️ ¡Alguien ha vuelto! Reanudando la música.`);
                                 try {
                                     // Enviar mensaje temporal de reanudación
                                     const msg = await guildData.lastInteraction?.channel?.send({ embeds: [resumeEmbed] });
                                     setTimeout(() => msg?.delete().catch(()=>{}), 10000);
                                 } catch (e) { console.error(`[${guildId}] VSU: Error enviando embed de reanudación:`, e); }
                             } else { console.warn(`[${guildId}] VSU: player.unpause() devolvió false.`); }
                         } catch(e){ console.error(`[${guildId}] VSU: Error en player.unpause():`, e); }
                    }
                }
            }
        } catch (logicError) {
             console.error(`[${guildId}] VSU: Error en la lógica principal:`, logicError);
             // Considerar si se debe hacer alguna limpieza aquí en caso de error lógico inesperado
        }
    }, // Fin execute
}; // Fin module.exports